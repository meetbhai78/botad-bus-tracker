import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/socket_service.dart';
import 'bus_list_screen.dart';
import 'search_buses_screen.dart';
import 'timetable_screen.dart';

class MapScreen extends StatefulWidget {
  final String? targetBusId;
  const MapScreen({super.key, this.targetBusId});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final _socket = PassengerSocketService();
  LatLng _center = const LatLng(22.1647, 71.6661);
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  bool _hasFocusedOnTarget = false;

  @override
  void initState() {
    super.initState();
    _socket.onBuses = _updateMarkers;
    _socket.connect();
  }

  void _updateMarkers(List<dynamic> buses) {
    if (!mounted) return;
    setState(() {
      _markers = buses
          .where((b) => b['lat'] != null && b['lng'] != null)
          .map((b) {
            final lat = b['lat'] as double;
            final lng = b['lng'] as double;
            
            // Auto-focus logic if a specific bus was searched
            if (widget.targetBusId != null && b['busId'] == widget.targetBusId) {
              if (!_hasFocusedOnTarget || _mapController != null) {
                _mapController?.animateCamera(CameraUpdate.newLatLngZoom(LatLng(lat, lng), 16));
                _hasFocusedOnTarget = true;
              }
            }

            return Marker(
              markerId: MarkerId(b['busId'].toString()),
              position: LatLng(lat, lng),
              icon: widget.targetBusId == b['busId'] 
                  ? BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen) 
                  : BitmapDescriptor.defaultMarker,
              infoWindow: InfoWindow(
                title: b['busName']?.toString() ?? 'Bus',
                snippet: b['eta'] != null ? 'ETA ${b['eta']} min' : null,
              ),
            );
          })
          .toSet();
    });
  }

  @override
  void dispose() {
    _socket.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Botad Bus Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.schedule),
            tooltip: 'Timetable & Stops',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TimetableScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.search),
            tooltip: 'Search Routes',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchBusesScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.list),
            tooltip: 'All Active Buses',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const BusListScreen()),
            ),
          ),
        ],
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(target: _center, zoom: 14),
        markers: _markers,
        myLocationEnabled: true,
        onMapCreated: (controller) => _mapController = controller,
      ),
    );
  }
}
